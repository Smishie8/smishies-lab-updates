$ErrorActionPreference = 'Stop'
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Join-Path $env:LOCALAPPDATA 'SmishiesLab'
$Target = Join-Path $Root 'App'
New-Item -ItemType Directory -Force -Path $Target | Out-Null

Write-Host "Installation de Smishie's Lab dans $Target"
$exclude = @('invokers.db','update_config.json')
Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
    if ($exclude -contains $_.Name -and (Test-Path (Join-Path $Target $_.Name))) { return }
    Copy-Item -LiteralPath $_.FullName -Destination $Target -Recurse -Force
}

# Preserve/update profile directory outside app folder.
New-Item -ItemType Directory -Force -Path $Root | Out-Null

$desktop = [Environment]::GetFolderPath('Desktop')
$shortcutPath = Join-Path $desktop "Smishie's Lab.lnk"
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($shortcutPath)
$sc.TargetPath = Join-Path $Target 'LANCER_SMISHIES_LAB.bat'
$sc.WorkingDirectory = $Target
$sc.Description = "Smishie's Lab"
$sc.Save()

$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$shortcut2 = Join-Path $startMenu "Smishie's Lab.lnk"
Copy-Item -LiteralPath $shortcutPath -Destination $shortcut2 -Force

Write-Host ""
Write-Host "Installation terminee. Un raccourci a ete cree sur le Bureau."
Write-Host "Tu peux maintenant toujours lancer Smishie's Lab avec ce raccourci."
Start-Process -FilePath (Join-Path $Target 'LANCER_SMISHIES_LAB.bat')
