@echo off
setlocal
cd /d "%~dp0"
title Smishie's Lab

echo ========================================
echo          SMISHIE'S LAB
echo ========================================
echo Verification des mises a jour...

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 updater.py --check
  echo.
  echo Demarrage de Smishie's Lab...
  py -3 server.py
) else (
  python updater.py --check
  echo.
  echo Demarrage de Smishie's Lab...
  python server.py
)

if errorlevel 1 (
  echo.
  echo Smishie's Lab s'est arrete avec une erreur.
  pause
)
endlocal
