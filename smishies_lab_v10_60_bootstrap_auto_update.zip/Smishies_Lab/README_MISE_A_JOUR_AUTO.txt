SMISHIE'S LAB — MISE À JOUR AUTOMATIQUE
========================================

1) PREMIÈRE INSTALLATION (une seule fois)
Double-clique sur : INSTALLER_SMISHIES_LAB.bat

L'application est copiée ici :
%LOCALAPPDATA%\SmishiesLab\App

Un raccourci "Smishie's Lab" est créé sur le Bureau et dans le menu Démarrer.
À partir de là, lance toujours ce raccourci.

2) AU DÉMARRAGE
LANCER_SMISHIES_LAB.bat exécute updater.py avant server.py.
Si une nouvelle version existe :
- elle est téléchargée automatiquement ;
- son SHA-256 peut être vérifié ;
- les fichiers de l'application sont remplacés ;
- invokers.db et la configuration locale sont conservés ;
- la nouvelle version démarre ensuite normalement.

3) SOURCE DES VERSIONS
Le système utilise un fichier JSON distant (manifest_url) de ce type :
{
  "version": "10.60",
  "channel": "stable",
  "url": "https://.../smishies_lab_v10_60.zip",
  "sha256": "..."
}

Le manifest_url est enregistré dans :
%LOCALAPPDATA%\SmishiesLab\update_config.json

La source distante doit être configurée une seule fois. GitHub Releases est recommandé.
Tant qu'aucune source n'est configurée, Smishie's Lab démarre normalement sans mise à jour.

4) DONNÉES CONSERVÉES
Les profils héros restent dans :
%LOCALAPPDATA%\SmishiesLab\hero_profiles.json
La base locale invokers.db est préservée lors des mises à jour.


V10.60: updater v2 prend aussi en charge les mises à jour fichier par fichier via GitHub.
