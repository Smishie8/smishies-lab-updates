@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLER_SMISHIES_LAB.ps1"
if errorlevel 1 pause
