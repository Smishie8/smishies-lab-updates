@echo off
setlocal
set CFG=%LOCALAPPDATA%\SmishiesLab\update_config.json
if not exist "%LOCALAPPDATA%\SmishiesLab" mkdir "%LOCALAPPDATA%\SmishiesLab"
if not exist "%CFG%" copy /Y "%~dp0update_config.json" "%CFG%" >nul
notepad "%CFG%"
endlocal
