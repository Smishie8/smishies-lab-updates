Smishie's Lab v10.49

Nouveau : onglet Meilleur support dans Simulation de combat. Recherche parmi Supports/Tanks, gain DPS total, buffs seuls, debuffs seuls, interaction et meilleur trio parmi les meilleurs candidats.

SMISHIE'S LAB V10.16

1. Double-clique sur LANCER_SMISHIES_LAB.bat
2. Garde la fenêtre noire ouverte pendant l'utilisation.
3. L'application s'ouvre sur http://127.0.0.1:8501

Nouveautés V10.16
- Les buffers utilisent leurs propres stats et niveaux sauvegardés.
- Leurs stats réellement utilisées sont affichées dans Simulation de combat.
- Conditions de buffs prises en compte (critique, non-critique, On kill).
- Contexte Adds / minions : Aucun / Rares / Fréquents.
- Nirvelle S3 ATK Up = On kill : aucun proc automatique contre un boss seul.
- Les fiches héros sont sauvegardées automatiquement.
- Les profils sont aussi stockés hors du dossier de l'application dans le profil Windows
  (LOCALAPPDATA/SmishiesLab/hero_profiles.json), afin de survivre aux futures mises à jour.


V10.25 : ajout du scanner ciblé PlayerAggregate (lecture seule) pour rechercher PlayerAggregate, ActualizePlayer, HeroOverviewModel, IDs de personnages et sets d'équipement dans les traces/caches locaux.

V10.27 : ConfigId transmis comme texte pour préserver les Int64 exacts (pas d'arrondi JavaScript). Le décodeur affiche aussi les occurrences exactes dans static-data et les tokens ASCII proches.

V10.28 : correction Buff Duration Extension : les effets '1 random buff' / 'up to 2 random buffs' prolongent désormais seulement le nombre demandé de buffs actifs, avec tirage déterministe.


V10.31 — Corrections mana validées en jeu
- Kisanka: combo 5 autos = 132 mana, S3 = +65 mana
- Kollodon: combo 5 autos = 86 mana
- Sinndra: combo 5 autos = 111 mana
- Lumisa: combo 5 autos = 132 mana
- Sodama: S3 = +74 mana
- Nyctra: S2 = +39 mana
- Tenso: S2 = +22 mana
- Recalcul des durées de combo via 36,66 mana/s et des totaux de séquence.

=== V10.35 — ÉLÉMENTS ===
- Ajout du champ Élément dans la fiche héros : Feu, Eau, Vent, Terre, Lumière, Ténèbres.
- Le matchup PvE est maintenant pris en compte dans Simulation, Comparateur, Optimisation et Classement.
- Avantage classique : +30% dégâts, +20 points de chance de débuff.
- Désavantage classique : -30% dégâts, -50 points Crit Rate, -50 points de chance de débuff.
- Lumière/Ténèbres -> Feu/Eau/Vent/Terre : +15% dégâts, +10 points de chance de débuff.
- Feu/Eau/Vent/Terre -> Lumière/Ténèbres : -15% dégâts, -25 points Crit Rate, -25 points de chance de débuff.
- Lumière <-> Ténèbres : avantage pour l'Invoker joueur en PvE.
- Astral : toujours neutre.
- Les supports utilisent aussi leur élément pour leurs critiques conditionnels et leurs tentatives de débuff.

IMPORTANT : la base V10.34 ne contenait pas l'élément des 222 héros. Les héros existants sont donc initialisés sur « Neutre ». Renseignez l'élément dans la Fiche héros ; il est sauvegardé avec le profil et réutilisé dans tous les modes.


V10.43 — Immunité contrôle des boss
- Mode réel : fiches sauvegardées des Supports/Tanks.
- Mode Best Support : PRE 1000, Skill Recovery 30 %, Skill Speed 30 %, tous les skills au maximum (♛).
- Les autres stats restent celles de la fiche du support.
- Le Top 3 affiche le profil et les stats/skills utilisés.


V10.43 — Tous les boss sont immunisés aux contrôles de foule (Shock, Stun, Freeze, Taunt, Pull/Push, Knockback, Suppression, etc.). Les debuffs non-CC restent actifs.


V10.44 — Analyse du meilleur trio
- Affiche la contribution marginale réelle de chaque support dans le trio retenu.
- Affiche le meilleur trio alternatif et l'écart de DPS.
- Signale le meilleur support individuel non retenu pour expliquer les redondances/synergies.


V10.47 — Box Auto-Mapping
- Ajout du mapping ConfigId -> nom des Invokers à partir du dataset 0.60.1302 du site Invokers.
- Le bouton « Décoder ma box » identifie automatiquement les héros connus.
- Le mapping est embarqué localement; aucune connexion Internet n'est nécessaire pendant l'import.


V10.50 - Import box : conservation de tous les exemplaires (InventoryId), box 904 préchargée, copies calculées sans écrasement.


V10.50 - Import Box + Reliques
- Décodage automatique des stats de PlayerRelicsModel.dat.
- Conservation de chaque relique équipée par InventoryId.
- Calcul du build du meilleur exemplaire : ATQ plat/%, Crit Rate, Crit DMG, PRÉ, RÉS, Combo Speed, Skill Speed, Skill Recovery.
- Injection automatique des stats calculées dans les fiches utilisées par Combat, Comparateur, Analyse et Classement.
- Mana et stat ID 11 conservés mais non injectés tant que leur échelle n'est pas validée.
- Lecture seule stricte des fichiers du jeu.

V10.51 - INVENTAIRE COMPLET DES RELIQUES
----------------------------------------
Après « Décoder ma box » puis « Importer cette box », Smishie's Lab importe désormais TOUTES les reliques présentes dans PlayerRelicsModel.dat, y compris celles qui ne sont équipées sur aucun héros.

Un nouvel onglet « Mes reliques » permet de voir :
- nombre total de reliques possédées ;
- reliques équipées / non équipées ;
- héros porteur quand elle est équipée ;
- slot, étoiles/rang, niveau, set, rareté et toutes les stats décodées ;
- filtres par slot, set, statut équipé et type de stat.

Les fichiers Invokers restent ouverts en lecture seule.

=== V10.52 — OPTIMISEUR DPS DE RELIQUES ===
Dans l'onglet Optimisation > Optimiseur de reliques DPS :
- Choisis le héros, le boss et la durée.
- Mode "Toute ma collection" : peut proposer de déplacer une relique portée par un autre héros.
- Mode "Disponibles + reliques du héros" : ne démonte pas les autres héros.
- Clique "Optimiser mes 8 reliques".
Le moteur présélectionne les meilleures reliques de chaque slot puis simule les meilleures combinaisons avec le moteur de combat.
Il affiche DPS actuel, DPS optimisé, gain %, stats finales et les 8 reliques à garder/changer.
Limites actuelles : les bonus de SET ne sont pas encore intégrés ; la génération de mana des reliques reste non appliquée tant que son échelle n'est pas validée.


=== V10.53 — OPTIMISEUR SETS + MANA ===
- Génération de mana des reliques appliquée comme un pourcentage réel.
- Bonus 3 pièces / 5 pièces inclus dans l'optimiseur (le palier 5 cumule le palier 3).
- Sets pris en charge pour le DPS : Attack, Crit Rate, Crit DMG, Accuracy, Resistance, Mana Gen, Spark, Fury, Vampire, Predator.
- Health/Defense/Instinct/Paragon sont reconnus ; leurs effets non-DPS ne changent pas le score solo.
- L'optimiseur conserve des candidats de chaque set afin de ne pas éliminer trop tôt une synergie 3p/5p.


V10.54 — SETS COMPLETS + OPTIMISEUR SÉCURISÉ
- Table complète standard/avancée/tolérances.
- Les paliers 3p et 5p sont additifs et le total est affiché.
- Le build équipé est toujours simulé comme finaliste : aucune recommandation ne peut avoir un DPS inférieur.
- Recherche élargie pour Sildrea (Crit/Skill Speed/Recovery/CDR sur Ult).


V10.55 : les slots de reliques sont désormais affichés avec les noms officiels : Arme, Bouclier, Casque, Épaulières, Gantelets, Plastron, Ceinture, Bottes.

V10.58 — OPTIMISEUR DE SETS
- Nouveau sous-menu Optimisation > Optimiseur de sets.
- Classe les meilleures compositions 3p/5p réellement faisables avec la collection importée.
- Le classement final utilise le simulateur de combat complet contre le boss et la durée choisis.
- Affiche DPS actuel, meilleur DPS, gain %, set conseillé et meilleures alternatives.
- Le moteur conserve les synergies de sets pendant la recherche et ne recommande jamais un build sous le DPS actuel comme meilleur build.

=== V10.59 — INSTALLATION + MISE À JOUR AUTOMATIQUE ===
- Installation permanente dans %LOCALAPPDATA%\SmishiesLab\App.
- Raccourci Bureau/Menu Démarrer créé automatiquement.
- Vérification automatique des mises à jour à chaque démarrage.
- Téléchargement + vérification SHA-256 + remplacement automatique des fichiers.
- invokers.db, profils héros et configuration locale préservés.
- La source distante (manifest_url) doit être configurée une seule fois ; GitHub Releases recommandé.
